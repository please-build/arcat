print("and now for something completely different")
