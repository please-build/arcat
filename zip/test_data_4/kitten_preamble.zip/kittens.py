print("kittens!")
